#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import threading
from check import platform
from settings import SFTP_HOST, SFTP_USER, SFTP_PASS, VERSION


def update():
	if(platform() == "windows"):
		r = requests.get('https://raw.githubusercontent.com/nbit-sec/impulse/master/updates/windows/impulse')
		fl = r.text.split('\n', 1)[0]
		ls = fl.split('# ')
		ver = ''.join(ls)
		if(str(ver) >= VERSION):
			print("New update available : " + ver)
		else:
			print("No updates available")
	elif(platform() == "linux"):
		r = requests.get('https://raw.githubusercontent.com/nbit-sec/impulse/master/updates/linux/impulse')
		fl = r.text.split('\n', 1)[0]
		ls = fl.split('# ')
		ver = ''.join(ls)
		if(str(ver) >= VERSION):
			print("New update available : " + ver)
		else:
			print("No updates available")
	elif(platform() == "mac"):
		r = requests.get('https://raw.githubusercontent.com/nbit-sec/impulse/master/updates/mac/impulse')
		fl = r.text.split('\n', 1)[0]
		ls = fl.split('# ')
		ver = ''.join(ls)
		if(str(ver) >= VERSION):
			print("New update available : " + ver)
		else:
			print("No updates available")

def sync(interval, wf, iterations=0):
	if iterations != 1:
		threading.Timer(interval, sync, [interval, wf, (0 if iterations
			== 0 else iterations - 1)]).start()
	wf()