#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import paramiko
from settings import SFTP_HOST, SFTP_USER, SFTP_PASS

def backup():
	transport = paramiko.Transport((SFTP_HOST, 22))
	transport.connect(username=SFTP_USER,password=SFTP_PASS)
	sftp = paramiko.SFTPClient.from_transport(transport)