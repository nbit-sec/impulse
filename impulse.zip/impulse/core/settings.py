#!/usr/bin/env python3
# -*- coding: utf-8 -*-

VERSION = '1.0'
AUTHOR = 'nbit - Nico Duitsmann'

SFTP_HOST = 'ssh.nbit-sec.de'
SFTP_USER = 'nbit-sec.de'
SFTP_PASS = 'gvhgjvGVgh46645980GCghfc534eFCH64'