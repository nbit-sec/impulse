#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys, socket
from sys import platform as _platform

PLATFORM = ''

def platform():
	if(_platform == "linux" or _platform == "linux2"): PLATFORM = "linux"
	elif(_platform == "darwin"): PLATFORM = "mac"
	elif(_platform.startswith("win")): PLATFORM = "windows"
	return PLATFORM

def connection():
	try:
		host = socket.gethostbyname("www.google.com")
		s = socket.create_connection((host, 80), 2)
		return True
	except: pass
	return False

def architecture():
	_void_ptr_size = struct.calcsize('P')
	bit32 = _void_ptr_size * 8 == 32
	bit64 = _void_ptr_size * 8 == 64
	if(bit32 == True): return "32"
	else: return "64"

def virtual_machine():
	if(hasattr(sys, 'real_prefix')): return True
	else: return False